buff = []
base = []
def load(): # загрузка
    global base
    try:
        with open('БАЗА.txt', 'r') as f:
            text = f.read()
        base = list(map(int, text[1:-1].split(',')))
        print(f"base: {base}")
    except FileNotFoundError:    
         print("File not found")    
    
def save(rezult): # запись 
    out = open('ФАЙЛ_Промежуточных_Результатов.txt', 'a')
    for i in rezult:
        out.write(str(i))
    out.write('\n')    
    out.close()

def selection(step): # выборка с шагом step 
    for i in range(0, len(base), step):
        buff.append(base[i])
    print(f"selection with {step} step: {buff}")
    save(buff)
    return buff    

def complexStep():
    global base
    steps = int(input("how many steps: "))
    buff.clear()
    cnt=0
    stepsB = []
    for i in range(0, steps):
            stepsB.append(int(input('enter distanse of step № ' + str(i + 1) + ': ')))
    while cnt < len(base):
        for i in range(0, steps):
            try:
                buff.append(base[cnt])
            except IndexError:
                pass    
            cnt+=stepsB[i]
    print("rezult of complex steps: ")
    print(buff)
    save(buff)    

def start():
    load()
    print("simple step")
    x = int(input("Eetr step: "))
    selection(x)
    print("\ncomplex step")
    complexStep()

start()
